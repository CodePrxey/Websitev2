import json
from flask import Flask, render_template, request
app = Flask('app')

# @app.route('/')
# def hello_world():
#   return 'Sveiks apmeklētāj!'

@app.route('/')
def index():
  return render_template("index.html")

@app.route('/info.html')
def info():
  return render_template("info.html")

@app.route('/shop.html')
def shop():
  return render_template("shop.html")

@app.route('/test.html')
def test():
  return render_template("test.html")

@app.route('/api/pievienot',methods=['POST'])  
def pievienot_tehniku():
  datne="static/datorudb.json"
  with open(datne, "r", encoding = "utf-8") as f:
    dati = json.loads(f.read())
  lid=dati['lastId']
  lid=lid+1
  jauna_tehnika=json.loads(request.data)
  try:
    jauna_tehnika['id']=lid
    dati["dati"].append(jauna_tehnika)
    dati["lastId"]=lid
    with open(datne, "w", encoding = "utf-8") as f:
      f.write(json.dumps(dati))
    atbilde=1
  except: 
    atbilde=0

  return {'status':atbilde}

app.run(host='0.0.0.0', port=8080)